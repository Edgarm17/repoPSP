package productorsConsumidorsMonitors;

import java.util.Random;

public class App {

	public static void main(String[] args) throws InterruptedException{
		//creem el monitor: buffer
		MonitorBuffer buffer = new MonitorBuffer();
		//Creem el productor
		Productor p = new Productor(buffer);
		//Creem el consumidor
		Consumidor c = new Consumidor(buffer);
		//Creem els fils
		Thread productor = new Thread(p);
		Thread consumidor = new Thread(c);
		//Els fiquem en matxa
		productor.start();
		consumidor.start();

	}
	
	public static class MonitorBuffer{
		
		//recurs compartit: buffer: array de 10 integers
		private int[] buffer = new int[10];
		//index de l'element de l'array a agafar/ficar
		private int indexArray = 0;
		//variables de condició/sincronització
		private boolean bufferPle = false;
		private boolean bufferBuit = true;
	
		public synchronized void afegir(int num) {
			
			//Mentre el buffer estiga ple, espera
			while(bufferPle) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			//Afegim el número en la posició indicada per l'índex
			buffer[indexArray] = num;
			
			//mostrem per pantalla l'element afegit
			System.out.println("Index de l'element de l'array a afegir: "+indexArray);
			
			//mostrar array
			System.out.print("Array: ");
			for (int i = 0; i < indexArray; i++) {
				System.out.print(buffer[i]+" ");
			}
			System.out.println("");
			//actualitzem el valor de l'índex
			indexArray++;
			
			//Actualiztem els valors de les variables de condició
			if (indexArray == 9) {
				bufferPle = true;
			}
			
			//el buffer segur que no esta buit
			bufferBuit = false;
			
			//avisem que ja es pot accedir al buffer per a consumir
			notify(); 
			
		}
		
		public synchronized int agafar() {
			
			//Mentre el buffer estiga buit, espera
			while(bufferBuit) {
				try {
					wait();
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
			
			//Ha d'actualitzar el valor de la posició de l'element en l'array
			indexArray--;
			
			//Mostrem el valor de l'índex agafat
			System.out.println("Índex de l'element de l'array a agafar: "+indexArray);
			
			//mostrar array
			System.out.print("Array: ");
			for (int i = 0; i < indexArray; i++) {
				System.out.print(buffer[i]+" ");
			}
			System.out.println("");
			
			//si ja no queden elements a consumir
			if (indexArray == 0) {
				bufferBuit = true; 
			}
			
			//el buffer segur que ja no està ple
			bufferPle = false;
			
			//avisem que ja es pot accedir al buffer per a produir
			notify();
			
			//retornem el valor de l'element extret
			return buffer[indexArray];
		}
		
	}
	
	public static class Productor implements Runnable{
		
		private MonitorBuffer buff;

		public Productor(MonitorBuffer buffer) {
			buff = buffer;
		}

		@Override
		public void run() {
			int num = 0;
			//valor aleatori
			Random rn = new Random();
			//Produirá 10 elements
			for (int i = 0; i < 10; i++) {
				//generem numero aleatori
				num = (int) rn.nextInt(100);
				//mostra el numero
				System.out.println("Productor: Número produït: "+num);
				//Inserim l'element en el buffer
				buff.afegir(num);
				//esperem un temps
				try {
					Thread.sleep(rn.nextInt(1000));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		
	}

	public static class Consumidor implements Runnable{

		private MonitorBuffer buff;
		
		public Consumidor(MonitorBuffer buffer) {
			buff = buffer;
		}

		@Override
		public void run() {
			//per obtenir el valor de l'element del buffer
			int num;
			//valor aleatori
			Random rn = new Random();
			for (int i = 0; i <10; i++) {
				//obtenir el numero corresponent del buffer
				num = buff.agafar();
				System.out.println("Consumidor: Número agafat: "+num);
				//esperem un temps
				try {
					Thread.sleep(rn.nextInt(2000));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
	
	
	}

}


